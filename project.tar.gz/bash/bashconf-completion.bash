#!/usr/bin/env bash
complete -W "-h --help -s --silent" bashconf